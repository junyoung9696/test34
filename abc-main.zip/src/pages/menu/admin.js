import Navbar from "@/components/Navbar";

function admin() {
  return (
    <>
      <Navbar />

      <button>logout</button>
    </>
  );
}

export default admin;
